package com.cda.API.ProjetFilRouge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiProjetFilRougeApplicationTests {

	@Test
	void contextLoads() {
	}

}
