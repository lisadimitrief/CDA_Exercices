package com.projet.apiRouge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRougeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRougeApplication.class, args);
	}

}
